
# PM BY MADI — Website (Next.js 14)

Готовый минимальный проект для деплоя на Vercel.

## Скрипты

```bash
npm run dev
npm run build
npm start
```

Если деплой на Vercel — просто запушьте файлы в GitHub.
